Cara menjalankan dasboard
- install terlebih dahulu streamlit dengan perintah (pip install streamlit)
- kemudian unduh dasboard.py dan datanya hour
- setelah itu jalankan dengan perintah (streamlit run dashboard.py)
